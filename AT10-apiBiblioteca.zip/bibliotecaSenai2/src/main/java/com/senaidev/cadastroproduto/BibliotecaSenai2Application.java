package com.senaidev.cadastroproduto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BibliotecaSenai2Application {

	public static void main(String[] args) {
		SpringApplication.run(BibliotecaSenai2Application.class, args);
	}

}
