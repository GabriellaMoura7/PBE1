package com.senaidev.cadastroproduto;

import org.springframework.data.jpa.repository.JpaRepository;

import com.biblioteca.entities.Editora;

public interface EditoraRepository extends JpaRepository<Editora, Long>{

}
