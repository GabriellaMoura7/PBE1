package prjExercicio4;

public class Moto {
//SubClasse
	
	@Override
	public void metodoFrear() {
		System.out.println("A moto está freando");
	}
}
