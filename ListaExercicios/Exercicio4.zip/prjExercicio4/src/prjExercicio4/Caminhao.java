package prjExercicio4;

public class Caminhao {
//SubClasse 
	
	@Override
	public void metodoAcelerar() {
		System.out.println("O caminhão está acelerando");
	}
}
