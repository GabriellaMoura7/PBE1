package prjExercicio4;

public class Carro {
//SubClasse
	 
	@Override
	public void metodoAcelerar() {
		System.out.println("O carro está acelerando");
	}
}
