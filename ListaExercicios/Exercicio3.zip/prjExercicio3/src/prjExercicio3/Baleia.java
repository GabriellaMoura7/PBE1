package prjExercicio3;

public class Baleia {
	//SubClasse 
	
	public void metodoNadar() {
		System.out.println("A Baleia está nadando, splash splash");
	}
}
