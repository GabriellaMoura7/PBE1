package prjExercicio3;

public class Leao {
//SubClasse
	
	public void metodoCacar() {
		System.out.println("O Leão está caçando, uroooooooooar!!!");
	}
}
