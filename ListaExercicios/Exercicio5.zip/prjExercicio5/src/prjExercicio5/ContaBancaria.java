package prjExercicio5;

public class ContaBancaria {
//Atributos
	String titular;
	int numero;
	double saldo;
	
	//Construtores
	
	public ContaBancaria() {
		
	}
	
	public ContaBancaria(String titular, int numero, double saldo) {
		this.titular = titular;
		this.numero = numero;
		this.saldo = saldo;
	}
	
	//Metodos
	
	public void metodoDepositar() {
		
	}
	
}
