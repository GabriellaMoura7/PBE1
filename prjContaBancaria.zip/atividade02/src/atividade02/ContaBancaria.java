package atividade02;

import java.util.Scanner;

public class ContaBancaria {

	public static void main(String[] args) {
		
	  Scanner sc = new Scanner(System.in);
	  
	  System.out.println("Qual o número da sua conta bancária?");
	  int numero = sc.nextInt();
	  
	  System.out.println("Qual o nome do titular da conta?");
	  String nomeTitular = sc.nextLine();
	  
	  System.out.println("Qual o seu saldo atual?");
	  double saldo = sc.nextDouble();
	  
	  System.out.println("Você quer sacar ou depositar o seu dinheiro?");
		System.out.println("1. Depositar");
		System.out.println("2. Sacar");
		System.out.println("Escolha uma opção:");
		int escolha = sc.nextInt();
	  
		  
	  }
	  
	  
	}

}
