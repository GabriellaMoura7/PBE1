package br.com.senaimusic.modelos;

public class MinhasPreferidas {
	
	public void incluir(Audio audio) {
		if (audio.getClassificacao() >= 9) {
			System.out.println("Essa é top.");
		} else {
			System.out.println("Essa é paia.");
		}
	}

}
