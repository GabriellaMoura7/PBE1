package prjCarro;

import java.util.Scanner;

public class AndarDeCarro {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		String modelo;
		String marca;
		int velocidade;
		
		System.out.println("Opções: ");
		System.out.println("1. Acelerar");
		System.out.println("2. Frear");
		System.out.println("Escolha uma opção: ");
		int escolha = scanner.nextInt();
		
		if (escolha == 1) {
			System.out.println("Quanto você quer acelerar?");
			int valor = scanner.nextInt();
			int velocidade += valor;
		}
		else if (escolha == 2) {
			System.out.println("Quanto você quer freiar?");
			int valor = scanner.nextInt;
			velocidade += valor;
		}
			
		
		else {
			System.out.println("Opção inválida");
		}
		
		System.out.println();
		
		
		
		

	}

}
