package com.senaidev.cursosenai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CursoSenaiiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CursoSenaiiApplication.class, args);
	}

}
