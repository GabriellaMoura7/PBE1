package com.senaidev.cursosenai;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CursoSenaiiApplicationTests {

	@Test
	void contextLoads() {
	}

}
